#pragma once
#include "config_requirement.h"

// Tempat menambahkan konfigurasi tambahan (jika ada)
