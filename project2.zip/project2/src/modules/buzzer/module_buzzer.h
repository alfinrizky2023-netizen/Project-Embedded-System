#pragma once
#include <Arduino.h>
#include "config/config.h"

void initBuzzer(uint8_t pin);
