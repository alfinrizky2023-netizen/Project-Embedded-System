#pragma once
#include <Arduino.h>
#include "config/config.h"

void initOLED(uint8_t sda, uint8_t scl);
