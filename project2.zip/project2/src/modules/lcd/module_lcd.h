#pragma once
#include <Arduino.h>
#include "config/config.h"

void initLCD();
